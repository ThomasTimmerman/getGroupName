import React, {Component} from 'react'

class FooterComponent extends Component {
    render() {
        return (
            <footer className="footer">
                <span className="text-muted">Dit is een testpagina</span>

            </footer>
        )
    }
}


export default FooterComponent