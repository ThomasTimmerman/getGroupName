import React from 'react'

function ErrorComponent() {
    return <div>An Error Occurred. Contact Support</div>
}
export default ErrorComponent